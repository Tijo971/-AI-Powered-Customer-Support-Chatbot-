# ShopEasy Customer Support Chatbot

A small Python customer-support chatbot with a browser-based chat page. The
browser sends messages to a local Python HTTP server, which calls the locally
running Ollama model and returns a structured support reply.

## What is included

- `chat_bot.py` — chatbot logic, Ollama client, command-line interface, and
  built-in web server/API.
- `index.html` — responsive chat interface served by the Python web server.
- `chat_history.json` — conversation history saved by the command-line
  interface when it exits. Browser conversations are kept in server memory
  instead.

The project uses only Python's standard library; there are no Python packages
to install.

## Requirements

- Python 3.7 or later.
- Ollama installed and running on this computer.
- The model configured for the chatbot available in Ollama. The default is
  `llama3.2:latest`.

Check that Ollama is installed and the model is available:

```powershell
ollama --version
ollama list
```

If the default model is missing, download it:

```powershell
ollama pull llama3.2:latest
```

Ollama normally runs as a background application on Windows. If it is not
running, start it with:

```powershell
ollama serve
```

Keep Ollama running while using the chatbot. Its default API address is
`http://localhost:11434`.

## Run the browser chat

Open PowerShell in the project folder:

```powershell
cd "E:\agents\New folder\customer_support_chatport"
python chat_bot.py --web
```

The server prints its address. Open the default address in a browser:

```text
http://127.0.0.1:8000
```

Type a message and select **Send**. Select **New chat** to clear the
conversation for that browser. Stop the web server with **Ctrl+C** in its
PowerShell window.

### Change the model, Ollama URL, or web address

Set environment variables before starting the server:

```powershell
$env:OLLAMA_MODEL = "llama3.2:latest"
$env:OLLAMA_HOST = "http://localhost:11434"
$env:CHAT_HOST = "127.0.0.1"
$env:CHAT_PORT = "8000"
python chat_bot.py --web
```

The equivalent command-line options for the web server are:

```powershell
python chat_bot.py --web --host 127.0.0.1 --port 8000
```

The default host only accepts connections from this computer. Binding to a
network interface such as `0.0.0.0` exposes the app to other machines on the
network; this simple server has no login or HTTPS and should not be exposed to
the public internet.

## Working flow

```text
Browser (index.html)
  ├─ GET /                  → Python server returns index.html
  ├─ POST /api/chat         → Python reads the message and finds the browser session
  │                            ↓
  │                         SupportBot checks input and adds it to conversation history
  │                            ↓
  │                         Python POSTs to Ollama /api/chat
  │                            ↓
  │                         Ollama generates a JSON support answer
  │                            ↓
  │                         Python validates/normalizes the JSON and returns it
  └─ POST /api/reset        → Python clears that browser session's history
```

1. The browser requests `/`. The Python server reads `index.html` from the
   same folder as `chat_bot.py`.
2. When a customer sends a message, the page posts JSON to `/api/chat`.
3. The server identifies the browser using an HTTP-only `support_session`
   cookie. A new browser gets a new in-memory `SupportBot`; conversations are
   isolated per browser session.
4. `SupportBot` rejects blank or over-limit messages, politely declines clearly
   unrelated topics, and answers a few simple name, purchase, and project
   recall questions from recent history. Other in-scope questions are sent with
   the system prompt and recent conversation turns to Ollama.
5. Ollama returns its message content. The bot parses and validates the
   required fields. If the first response is invalid JSON, it asks Ollama once
   to correct the format.
6. The server returns the structured reply. The page displays the answer,
   category, confidence, optional next steps, and human-escalation notice.
7. **New chat** posts to `/api/reset`, clearing the conversation history for
   that browser without affecting other browser sessions.

## Example conversation

For example, a customer may type:

```text
Where is my order?
```

The browser sends a request like:

```http
POST /api/chat HTTP/1.1
Content-Type: application/json

{"message":"Where is my order?"}
```

The server forwards the system prompt and conversation to Ollama. The model
response is requested in JSON format and is validated by the bot. A possible
browser API response is:

```json
{
  "answer": "I can help check on your shipment. Please provide your order number.",
  "category": "shipping",
  "confidence": "high",
  "next_steps": ["Find the order number in your confirmation email"],
  "needs_human": false
}
```

The exact answer depends on the model. The bot is instructed not to invent
order numbers, prices, or store policies.

The page displays the answer and any next steps in Ava's message bubble. If
`needs_human` is `true`, it also displays a notice that a support agent may be
needed. This is a notice only; the app does not create or route a real support
ticket. Alongside ShopEasy support, the bot can answer general customer-support
and ERP questions such as purchase orders, order management, CRM, ERP
integration, and basic technology/AI concepts.

## API reference

### `GET /`

Returns the chat page (`index.html`).

### `POST /api/chat`

Accepts a JSON object with a string `message`:

```json
{"message": "Hello, I am Tijo"}
```

A successful request returns a JSON reply:

```json
{
  "answer": "Hello Tijo! How can I help you today?",
  "category": "general",
  "confidence": "high",
  "next_steps": [],
  "needs_human": false
}
```

The reply values are model-generated, so the example wording is illustrative.
The default reply uses these fields. If the customer explicitly asks for a
supported custom JSON schema such as `message`, `status`, and `needs_human`,
the bot validates and returns that requested schema as well.
The response fields are:

| Field | Meaning |
|---|---|
| `answer` | Short reply for the customer. |
| `category` | One of `billing`, `shipping`, `technical`, `account`, or `general`. |
| `confidence` | One of `high`, `medium`, or `low`. |
| `next_steps` | List of suggested actions. |
| `needs_human` | Whether the model recommends a human follow-up. |

Malformed JSON or a missing/non-string message returns HTTP 400. Request bodies
larger than 16 KB return HTTP 413. A model/network failure is logged by the
server and returns the chatbot's fallback reply.

### `POST /api/reset`

Clears the current browser session's history and returns:

```json
{"ok": true}
```

## Run the command-line chatbot

The browser mode is optional. To use the original terminal interface instead:

```powershell
python chat_bot.py
```

Type a question at the prompt. The CLI loads `chat_history.json` on startup.
Type `reset` to clear the in-memory conversation, or `quit`/`exit` to leave.
On exit, the CLI saves the current history to `chat_history.json`.

Run the automated regression checks with:

```powershell
python -m unittest -v test_chat_bot
```

`SupportBot` accepts an injectable HTTP client for deterministic transport
tests. Supplying a custom client disables the live-input topic gate by default,
so the PDF's Python/Django prompts can exercise mocked errors; pass
`enforce_scope=True` when an injected client should also enforce topic limits.

## Settings and behavior

| Setting | Default | Description |
|---|---|---|
| `OLLAMA_MODEL` | `llama3.2:latest` | Local Ollama model name. |
| `OLLAMA_HOST` | `http://localhost:11434` | Ollama server base URL. |
| `CHAT_HOST` | `127.0.0.1` | Web server bind address. |
| `CHAT_PORT` | `8000` | Web server port. |
| `MAX_TOKENS` | `600` | Maximum generated tokens requested from Ollama. |
| `MAX_HISTORY_TURNS` | `10` | Maximum recent user/assistant pairs sent to the model. |
| `MAX_INPUT_CHARS` | `2000` | Maximum message length accepted by the bot. |
| `MAX_RETRIES` | `3` | Maximum Ollama attempts for transient failures. |

Transient network errors, HTTP 429 responses, and server errors are retried
with exponential backoff. Other HTTP client errors are not retried. If Ollama
reports that a model was not found, install it with `ollama pull <model>` or
set `OLLAMA_MODEL` to a name shown by `ollama list`.

## Current limitations

- Browser conversation history is in memory. Restarting the Python server
  clears browser sessions and their histories.
- The CLI history file is separate from browser sessions.
- Topic filtering is intentionally lightweight; it is not a general-purpose
  semantic moderation or intent-classification system.
- The chatbot uses the configured local Ollama model; it does not connect to
  a database, retrieve order data, or create support tickets.
- This is a simple local development app. It has no user authentication,
  persistent browser-session storage, production-grade server, or HTTPS.
