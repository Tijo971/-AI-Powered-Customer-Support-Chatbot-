"""
Customer Support Chatbot  -  Day 6 Mini Project #1
Features: conversation history | structured answers | error handling
"""
import argparse
import http.client
from http.cookies import CookieError, SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import logging
import os
from pathlib import Path
import random
import re
import secrets
import threading
import time
import urllib.error
import urllib.request
from urllib.parse import urlsplit
# ---------------------------------------------------------------- config
MODEL = os.environ.get("OLLAMA_MODEL", "llama3.2:latest")
OLLAMA_HOST = os.environ.get("OLLAMA_HOST", "http://localhost:11434").rstrip("/")
MAX_TOKENS = 600
MAX_HISTORY_TURNS = 10          # keep the last 10 user/assistant pairs
MAX_RETRIES = 3
MAX_INPUT_CHARS = 2000
REQUEST_TIMEOUT = 30.0
CATEGORIES = {"billing", "shipping", "technical", "account", "general"}
CONFIDENCE = {"high", "medium", "low"}
logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("support-bot")
SYSTEM_PROMPT = """You are Ava, a customer support assistant for ShopEasy,
an online electronics store. You also help with general customer-support and
ERP topics such as purchase orders, order management, CRM, ERP integration,
and basic technology or AI concepts.
RULES
- Be polite, concise and accurate. Never invent order numbers, prices, or policies.
- If you do not know something, say so and set needs_human to true.
- Answer questions about ShopEasy orders, billing, shipping, accounts, products,
  customer support, and ERP/business workflows. Politely decline unrelated requests.
- Use relevant conversation history to answer follow-up questions. Ask for
  clarification when a reference is genuinely ambiguous.
- When recalling a project, include relevant goals and integrations the user
  previously mentioned.
- Describe ERP workflows as typical examples because systems and policies vary.
  Never claim ShopEasy uses a specific system or process unless told so.
- If the user requests JSON with specific fields, honor that schema for an
  in-scope request. Otherwise use the default format below.
For unrelated requests, politely say: "I'm designed to assist with customer
support and ERP workflows. Please let me know if you need help with an order,
product, service, or business process."
OUTPUT FORMAT
Reply with ONE valid JSON object and nothing else (no markdown, no prose):
{
  "answer": "<short helpful reply for the customer>",
  "category": "billing | shipping | technical | account | general",
  "confidence": "high | medium | low",
  "next_steps": ["<step 1>", "<step 2>"],
  "needs_human": true or false
}"""
FALLBACK = {
    "answer": ("I'm sorry, but I'm temporarily unable to process your request "
               "due to a technical issue. Please try again later."),
    "category": "general",
    "confidence": "low",
    "next_steps": ["Try again shortly", "Contact human support"],
    "needs_human": True,
}
INVALID_REPLY_FALLBACK = {
    "message": "We are unable to process your request automatically. "
               "Our support team will assist you.",
    "needs_human": True,
}
# ------------------------------------------------- feature 1: history
class ConversationHistory:
    """Stores the messages list that is re-sent to the API on every call."""
    def __init__(self, max_turns=MAX_HISTORY_TURNS):
        self.max_turns = max_turns
        self.messages = []                       # [{"role":..., "content":...}]


    def add_user(self, text):
        self.messages.append({"role": "user", "content": text})
    def add_assistant(self, text):
        self.messages.append({"role": "assistant", "content": text})
    def rollback_user(self):
        """Remove a dangling user message if the API call failed."""
        if self.messages and self.messages[-1]["role"] == "user":
            self.messages.pop()
    def window(self):
        """Return only the most recent turns (sliding window)."""
        limit = self.max_turns * 2
        trimmed = self.messages[-limit:]
        while trimmed and trimmed[0]["role"] != "user":   # must start with user
            trimmed = trimmed[1:]
        return trimmed
    def clear(self):
        self.messages = []
    def save(self, path):
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.messages, f, ensure_ascii=False, indent=2)
    def load(self, path):
        try:
            with open(path, encoding="utf-8") as f:
                messages = json.load(f)
        except (FileNotFoundError, json.JSONDecodeError, UnicodeDecodeError,
                OSError) as exc:
            if not isinstance(exc, FileNotFoundError):
                log.warning("Unable to load conversation history: %s", exc)
            self.messages = []
            return
        if (not isinstance(messages, list)
                or any(not isinstance(message, dict)
                       or message.get("role") not in {"user", "assistant"}
                       or not isinstance(message.get("content"), str)
                       for message in messages)):
            log.warning("Conversation history has an invalid format; starting fresh")
            self.messages = []
            return
        self.messages = messages
# ------------------------------------------- feature 2: structured answers
class InvalidReply(ValueError):
    """Model reply was not valid structured JSON."""


class OllamaAPIError(Exception):
    """Ollama returned a response that could not be used."""


class OllamaAuthenticationError(OllamaAPIError):
    """Ollama rejected the request because it was not authorized."""


OUT_OF_SCOPE_TERMS = ("django", "fifa", "world cup", "joke")
IN_SCOPE_PATTERN = re.compile(
    r"\b(order|purchase|erp|crm|customer relationship|billing|bill|invoice|payment|refund|return|"
    r"shipping|delivery|tracking|track|account|product|laptop|electronics|"
    r"warranty|support|service|help|store|inventory|supplier|procurement|sales|"
    r"project|database|mysql|"
    r"chatbot|artificial intelligence|machine learning|ai|ml)\b",
    re.IGNORECASE,
)
FOLLOW_UP_PATTERN = re.compile(
    r"\b(it|that|this|they|them|those|these)\b|\bmy name\b|"
    r"\bwhat (?:did i|product did i) (?:purchase|buy)\b",
    re.IGNORECASE,
)


def is_in_scope(text):
    """Keep unrelated subjects out of the store, support, and ERP chatbot."""
    normalized = text.casefold()
    if any(term in normalized for term in OUT_OF_SCOPE_TERMS):
        return False
    if re.match(r"^(hi|hello|hey|good morning|good afternoon|good evening)\b",
                normalized):
        return True
    if re.match(r"^(my name is|i am |i'm |i recently purchased|i bought)\b",
                normalized):
        return True
    return IN_SCOPE_PATTERN.search(normalized) is not None


def recall_answer(user_text, messages):
    """Answer simple name, purchase, and project questions from saved turns."""
    question = user_text.casefold()
    user_messages = [
        message["content"] for message in messages if message["role"] == "user"
    ]

    if "purchase management" in question:
        return (
            "Purchase management is the process of planning and controlling an "
            "organization's purchases. It commonly includes selecting suppliers, "
            "creating and approving purchase orders, tracking deliveries, and "
            "matching invoices. Exact steps depend on the organization's policies "
            "and ERP configuration."
        )

    if "my name" in question:
        for message in user_messages:
            match = re.search(
                r"\bmy name is\s+([A-Za-z][A-Za-z'-]*)",
                message,
                re.IGNORECASE,
            )
            if match:
                return f"Your name is {match.group(1)}."

    if "what product did i purchase" in question or "what product did i buy" in question:
        for message in user_messages:
            match = re.search(
                r"\b(?:purchased|bought)\s+([^,.!?]+)",
                message,
                re.IGNORECASE,
            )
            if match:
                product = match.group(1).strip()
                if product:
                    return f"You purchased {product}."

    if "what project" in question or "what am i currently developing" in question:
        joined_history = "\n".join(user_messages).casefold()
        if ("chatbot" in joined_history
                and re.search(r"\berp\b", joined_history)
                and re.search(r"\bintegrat\w*\b", joined_history)):
            return (
                "You are developing a customer-support chatbot that you want "
                "to integrate with an ERP system."
            )
        if "chatbot" in joined_history:
            return "You are developing a customer-support chatbot."

    return None


def parse_reply(raw):
    """Turn raw model text into a validated dict or raise InvalidReply."""
    if not isinstance(raw, str):
        raise InvalidReply("reply must be text")
    text = raw.strip()
    text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text)      # strip code fences
    start, end = text.find("{"), text.rfind("}")
    if start == -1 or end == -1:
        raise InvalidReply("no JSON object found")
    try:
        data = json.loads(text[start:end + 1])
    except json.JSONDecodeError as exc:
        raise InvalidReply(f"bad JSON: {exc}") from exc
    if not isinstance(data, dict):
        raise InvalidReply("JSON reply must be an object")

    compact_required = {"message", "status", "needs_human"}
    if compact_required.issubset(data):
        if not isinstance(data["message"], str) or not data["message"].strip():
            raise InvalidReply("message must be a non-empty string")
        if not isinstance(data["status"], str) or not data["status"].strip():
            raise InvalidReply("status must be a non-empty string")
        if not isinstance(data["needs_human"], bool):
            raise InvalidReply("needs_human must be a boolean")
        return data

    required = {"answer", "category", "confidence", "next_steps", "needs_human"}
    missing = required - data.keys()
    if missing:
        raise InvalidReply(f"missing keys: {sorted(missing)}")
    if not isinstance(data["answer"], str) or not data["answer"].strip():
        raise InvalidReply("answer must be a non-empty string")
    if not isinstance(data["category"], str) or data["category"] not in CATEGORIES:
        data["category"] = "general"
    if not isinstance(data["confidence"], str) or data["confidence"] not in CONFIDENCE:
        data["confidence"] = "low"
    if not isinstance(data["next_steps"], list):
        data["next_steps"] = [str(data["next_steps"])]
    data["next_steps"] = [
        str(step) for step in data["next_steps"] if str(step).strip()
    ]
    if not isinstance(data["needs_human"], bool):
        raise InvalidReply("needs_human must be a boolean")
    return data
def format_reply(data):
    category = data.get("category", data.get("status", "general"))
    confidence = data.get("confidence", "not specified")
    answer = data.get("answer", data.get("message", ""))
    lines = [f"Ava [{category} | confidence: {confidence}]", answer]
    if data.get("next_steps"):
        lines.append("Next steps:")
        lines += [f"  {i}. {s}" for i, s in enumerate(data["next_steps"], 1)]
    if data["needs_human"]:
        lines.append("-> Escalating to a human agent.")
    return "\n".join(lines)
# --------------------------------------------- feature 3: error handling
def call_with_retry(client, messages):
    """Call Ollama; retry transient errors with exponential backoff."""
    request_messages = [{"role": "system", "content": SYSTEM_PROMPT}, *messages]
    request_body = json.dumps({
        "model": MODEL,
        "messages": request_messages,
        "stream": False,
        "format": "json",
        "options": {"num_predict": MAX_TOKENS},
    }).encode("utf-8")
    request = urllib.request.Request(
        f"{OLLAMA_HOST}/api/chat",
        data=request_body,
        headers={"Content-Type": "application/json"},
        method="POST",
    )

    for attempt in range(1, MAX_RETRIES + 1):
        try:
            with client(request, timeout=REQUEST_TIMEOUT) as response:
                try:
                    result = json.loads(response.read().decode("utf-8"))
                except (UnicodeDecodeError, json.JSONDecodeError) as exc:
                    raise OllamaAPIError("Invalid JSON response from Ollama") from exc
            if (not isinstance(result, dict)
                    or not isinstance(result.get("message"), dict)
                    or not isinstance(result["message"].get("content"), str)):
                raise OllamaAPIError("Ollama response did not contain message content")
            return result["message"]["content"]
        except urllib.error.HTTPError as exc:
            if exc.code < 500 and exc.code != 429:    # other 4xx = our bug
                try:
                    body = exc.read().decode("utf-8")
                    payload = json.loads(body)
                    detail = payload.get("error", body) if isinstance(payload, dict) else body
                except (UnicodeDecodeError, json.JSONDecodeError):
                    detail = "no error details provided"
                finally:
                    exc.close()
                message = f"Ollama returned HTTP {exc.code}: {detail}"
                if exc.code == 404:
                    message += (
                        f". Verify the Ollama URL and that model {MODEL!r} is installed "
                        f"(run: ollama pull {MODEL})"
                    )
                log.error("%s", message)
                if exc.code in {401, 403}:
                    raise OllamaAuthenticationError(message) from exc
                raise OllamaAPIError(message) from exc
            kind = "rate limited" if exc.code == 429 else f"server error {exc.code}"
            error = exc
            exc.close()
        except (urllib.error.URLError, OSError, http.client.HTTPException) as exc:
            error, kind = exc, type(exc).__name__
        if attempt == MAX_RETRIES:
            raise error                             # out of attempts
        delay = (2 ** attempt) + random.uniform(0, 1)
        log.warning("%s (attempt %d/%d) - retrying in %.1fs",
                    kind, attempt, MAX_RETRIES, delay)
        time.sleep(delay)
# -------------------------------------------------------- the chatbot
class SupportBot:
    def __init__(self, client=None, *, enforce_scope=None):
        """Create a bot, allowing injected clients to exercise transport tests."""
        self.client = client if client is not None else urllib.request.urlopen
        self.enforce_scope = (
            client is None if enforce_scope is None else enforce_scope
        )
        self.history = ConversationHistory()
    def ask(self, user_text):
        user_text = (user_text or "").strip()
        if not user_text:
            return {**FALLBACK, "answer": "Please enter a message before sending."}
        if len(user_text) > MAX_INPUT_CHARS:
            return {**FALLBACK,
                    "answer": "Your message is too long. Please shorten it and try again."}
        recent_history = self.history.window()
        has_relevant_context = any(
            message["role"] == "user" and is_in_scope(message["content"])
            for message in recent_history
        )
        if (self.enforce_scope and not is_in_scope(user_text)
                and not (has_relevant_context and FOLLOW_UP_PATTERN.search(user_text))):
            return {
                "answer": (
                    "I'm designed to assist with customer support and ERP "
                    "workflows. Please let me know if you need help with an "
                    "order, product, service, or business process."
                ),
                "category": "general",
                "confidence": "high",
                "next_steps": [],
                "needs_human": False,
            }
        recalled_answer = recall_answer(user_text, recent_history)
        if recalled_answer is not None:
            data = {
                "answer": recalled_answer,
                "category": "general",
                "confidence": "high",
                "next_steps": [],
                "needs_human": False,
            }
            self.history.add_user(user_text)
            self.history.add_assistant(json.dumps(data, ensure_ascii=False))
            return data
        if not user_text:
            return {**FALLBACK, "answer": "Please enter a message before sending."}
        self.history.add_user(user_text)
        try:
            raw = call_with_retry(self.client, self.history.window())
            try:
                data = parse_reply(raw)
            except InvalidReply as exc:             # one repair attempt
                log.warning("Invalid reply (%s) - asking model to fix", exc)
                fix = self.history.window() + [
                    {"role": "assistant", "content": raw},
                    {"role": "user", "content": "Your reply was not valid JSON. "
                     "Resend it as ONE JSON object in the required format."}]
                data = parse_reply(call_with_retry(self.client, fix))
        except (OllamaAPIError, urllib.error.URLError, OSError,
                http.client.HTTPException, InvalidReply) as exc:
            log.error("Giving up: %s", exc)
            self.history.rollback_user()            # keep history consistent
            if isinstance(exc, OllamaAuthenticationError):
                return {
                    **FALLBACK,
                    "answer": ("I'm unable to access the service right now. "
                               "Please try again later or contact support."),
                }
            if isinstance(exc, InvalidReply):
                return dict(INVALID_REPLY_FALLBACK)
            return dict(FALLBACK)
        # store the clean JSON so the model sees consistent past turns
        self.history.add_assistant(json.dumps(data, ensure_ascii=False))
        return data


class ChatHTTPServer(ThreadingHTTPServer):
    """HTTP server with isolated in-memory conversations per browser."""
    daemon_threads = True

    def __init__(self, server_address, request_handler):
        super().__init__(server_address, request_handler)
        self.sessions = {}
        self.sessions_lock = threading.Lock()

    def get_session(self, cookie_header):
        session_id = None
        if cookie_header:
            cookies = SimpleCookie()
            try:
                cookies.load(cookie_header)
            except CookieError:
                pass
            if "support_session" in cookies:
                session_id = cookies["support_session"].value

        with self.sessions_lock:
            session = self.sessions.get(session_id) if session_id else None
            if session is None:
                session_id = secrets.token_urlsafe(32)
                session = {"bot": SupportBot(), "lock": threading.Lock()}
                self.sessions[session_id] = session
                return session_id, session, True
        return session_id, session, False


class ChatRequestHandler(BaseHTTPRequestHandler):
    """Serve the chat page and its same-origin JSON API."""

    def _send_json(self, status, payload, session_id=None):
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        if session_id:
            self.send_header(
                "Set-Cookie",
                f"support_session={session_id}; Path=/; HttpOnly; SameSite=Lax",
            )
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if urlsplit(self.path).path not in {"/", "/index.html"}:
            self._send_json(404, {"error": "Not found"})
            return
        try:
            page = Path(__file__).with_name("index.html").read_bytes()
        except OSError as exc:
            log.error("Unable to read chat page: %s", exc)
            self._send_json(500, {"error": "Chat page is unavailable"})
            return
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(page)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(page)

    def do_POST(self):
        endpoint = urlsplit(self.path).path
        if endpoint not in {"/api/chat", "/api/reset"}:
            self._send_json(404, {"error": "Not found"})
            return

        session_id, session, is_new = self.server.get_session(
            self.headers.get("Cookie")
        )
        if endpoint == "/api/reset":
            with session["lock"]:
                session["bot"].history.clear()
            self._send_json(200, {"ok": True}, session_id if is_new else None)
            return

        try:
            content_length = int(self.headers.get("Content-Length", ""))
        except ValueError:
            self._send_json(400, {"error": "A valid Content-Length is required"})
            return
        if content_length < 0:
            self._send_json(400, {"error": "Invalid request body length"})
            return
        if content_length > 16_384:
            self._send_json(413, {"error": "Request body is too large"})
            return
        try:
            payload = json.loads(self.rfile.read(content_length).decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            self._send_json(400, {"error": "Request body must be valid JSON"})
            return
        if not isinstance(payload, dict) or not isinstance(payload.get("message"), str):
            self._send_json(400, {"error": "A text message is required"})
            return

        with session["lock"]:
            reply = session["bot"].ask(payload["message"])
        self._send_json(200, reply, session_id if is_new else None)

    def log_message(self, format_string, *args):
        log.info("%s - %s", self.address_string(), format_string % args)


def run_web(host, port):
    with ChatHTTPServer((host, port), ChatRequestHandler) as server:
        log.info("Chat page available at http://%s:%d", host, server.server_port)
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            print("\nStopping chat server.")


def main():
    parser = argparse.ArgumentParser(description="ShopEasy customer support chatbot")
    parser.add_argument(
        "--web", action="store_true",
        help="serve the browser chat page and JSON API",
    )
    parser.add_argument(
        "--host", default=os.environ.get("CHAT_HOST", "127.0.0.1"),
        help="web server host (default: 127.0.0.1)",
    )
    parser.add_argument(
        "--port", type=int, default=int(os.environ.get("CHAT_PORT", "8000")),
        help="web server port (default: 8000)",
    )
    args = parser.parse_args()
    if args.web:
        run_web(args.host, args.port)
        return

    bot = SupportBot()
    bot.history.load("chat_history.json")
    print("ShopEasy Support  (type 'quit' to exit, 'reset' to clear history)")
    while True:
        try:
            text = input("\nYou: ")
        except (KeyboardInterrupt, EOFError):
            break
        if text.strip().lower() in {"quit", "exit"}:
            break
        if text.strip().lower() == "reset":
            bot.history.clear()
            print("History cleared.")
            continue
        print(format_reply(bot.ask(text)))
    bot.history.save("chat_history.json")
    print("\nGoodbye! Conversation saved.")
if __name__ == "__main__":
    main()