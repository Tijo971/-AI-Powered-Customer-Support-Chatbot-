import io
import json
import tempfile
import unittest
import urllib.error
from pathlib import Path
from unittest.mock import patch

import chat_bot


def ollama_response(content):
    if not isinstance(content, str):
        content = json.dumps(content)
    body = json.dumps({"message": {"content": content}}).encode("utf-8")
    return io.BytesIO(body)


class ChatBotTests(unittest.TestCase):
    def setUp(self):
        self.real_is_in_scope = chat_bot.is_in_scope
        self.allow_mocked_request = patch.object(
            chat_bot, "is_in_scope", return_value=True
        )
        self.allow_mocked_request.start()
        self.addCleanup(self.allow_mocked_request.stop)
        self.no_retry_delay = patch.object(chat_bot.time, "sleep")
        self.no_retry_delay.start()
        self.addCleanup(self.no_retry_delay.stop)

    def test_follow_up_requests_include_prior_conversation(self):
        answer = {
            "answer": "Your name is Tijo.",
            "category": "general",
            "confidence": "high",
            "next_steps": [],
            "needs_human": False,
        }
        requests = []

        def client(request, timeout):
            requests.append(json.loads(request.data)["messages"])
            return ollama_response(answer)

        bot = chat_bot.SupportBot(client)
        bot.ask("My name is Tijo. I recently purchased a laptop.")
        bot.ask("What color is my laptop?")

        self.assertIn("Tijo", json.dumps(requests[1]))
        self.assertIn("laptop", json.dumps(requests[1]))
        self.assertEqual(
            bot.ask("What is my name?")["answer"],
            "Your name is Tijo.",
        )

    def test_retries_rate_limit_and_connection_error_then_succeeds(self):
        calls = []

        def client(request, timeout):
            calls.append(request)
            if len(calls) == 1:
                raise urllib.error.HTTPError(
                    request.full_url, 429, "rate limited", {}, io.BytesIO(b"{}")
                )
            if len(calls) == 2:
                raise urllib.error.URLError("connection failed")
            return ollama_response(chat_bot.FALLBACK)

        chat_bot.SupportBot(client).ask("What is Artificial Intelligence?")
        self.assertEqual(len(calls), 3)

    def test_connection_failure_returns_fallback_and_rolls_back_user(self):
        calls = []

        def client(request, timeout):
            calls.append(request)
            raise urllib.error.URLError("connection failed")

        bot = chat_bot.SupportBot(client)
        reply = bot.ask("Explain what Python is.")

        self.assertEqual(len(calls), chat_bot.MAX_RETRIES)
        self.assertEqual(reply["answer"], chat_bot.FALLBACK["answer"])
        self.assertEqual(bot.history.messages, [])

    def test_authentication_error_is_not_retried(self):
        calls = []

        def client(request, timeout):
            calls.append(request)
            raise urllib.error.HTTPError(
                request.full_url, 401, "unauthorized", {},
                io.BytesIO(b'{"error":"unauthorized"}'),
            )

        reply = chat_bot.SupportBot(client).ask("Explain Django.")

        self.assertEqual(len(calls), 1)
        self.assertEqual(
            reply["answer"],
            "I'm unable to access the service right now. "
            "Please try again later or contact support.",
        )

    def test_client_error_is_not_retried_but_server_error_is(self):
        bad_request_calls = []

        def bad_request(request, timeout):
            bad_request_calls.append(request)
            raise urllib.error.HTTPError(
                request.full_url, 400, "bad request", {}, io.BytesIO(b"{}")
            )

        chat_bot.SupportBot(bad_request).ask("What is a REST API?")
        self.assertEqual(len(bad_request_calls), 1)

        server_calls = []

        def unavailable_once(request, timeout):
            server_calls.append(request)
            if len(server_calls) == 1:
                raise urllib.error.HTTPError(
                    request.full_url, 503, "unavailable", {},
                    io.BytesIO(b"{}"),
                )
            return ollama_response(chat_bot.FALLBACK)

        chat_bot.SupportBot(unavailable_once).ask("What is Django ORM?")
        self.assertEqual(len(server_calls), 2)

    def test_custom_json_schema_is_repaired_and_returned(self):
        outputs = iter([
            "Sure! Here you go.",
            {
                "message": "We apologize for the delay in your order.",
                "status": "pending",
                "needs_human": False,
            },
        ])
        calls = []

        def client(request, timeout):
            calls.append(request)
            return ollama_response(next(outputs))

        reply = chat_bot.SupportBot(client).ask(
            "Return JSON with message, status, and needs_human."
        )

        self.assertEqual(len(calls), 2)
        self.assertEqual(reply, {
            "message": "We apologize for the delay in your order.",
            "status": "pending",
            "needs_human": False,
        })

    def test_markdown_wrapped_custom_json_is_parsed(self):
        reply = chat_bot.parse_reply(
            '```json\n{"message":"Your delivery is delayed.",'
            '"status":"processing","needs_human":false}\n```'
        )
        self.assertEqual(reply, {
            "message": "Your delivery is delayed.",
            "status": "processing",
            "needs_human": False,
        })

    def test_two_invalid_replies_return_escalation_fallback(self):
        calls = []

        def client(request, timeout):
            calls.append(request)
            return ollama_response("not JSON")

        reply = chat_bot.SupportBot(client).ask("I need a refund.")

        self.assertEqual(len(calls), 2)
        self.assertEqual(reply, chat_bot.INVALID_REPLY_FALLBACK)

    def test_empty_and_overlong_messages_do_not_call_ollama(self):
        calls = []

        def client(request, timeout):
            calls.append(request)
            return ollama_response(chat_bot.FALLBACK)

        bot = chat_bot.SupportBot(client)
        empty_reply = bot.ask("")
        long_reply = bot.ask("x" * 3000)

        self.assertEqual(calls, [])
        self.assertEqual(
            empty_reply["answer"], "Please enter a message before sending."
        )
        self.assertEqual(
            long_reply["answer"],
            "Your message is too long. Please shorten it and try again.",
        )

    def test_history_window_keeps_latest_complete_turns(self):
        history = chat_bot.ConversationHistory(max_turns=2)
        for index in range(5):
            history.add_user(f"user {index}")
            history.add_assistant(f"assistant {index}")

        window = history.window()

        self.assertEqual(len(window), 4)
        self.assertEqual(window[0], {"role": "user", "content": "user 3"})

    def test_history_round_trip_restores_context(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "history.json"
            original = chat_bot.ConversationHistory()
            original.add_user("I am developing a customer-support chatbot.")
            original.add_assistant('{"answer":"You are developing a chatbot."}')
            original.add_user("I want to integrate it with an ERP system.")
            original.add_assistant('{"answer":"You plan to integrate it with ERP."}')
            original.save(path)

            restored = chat_bot.ConversationHistory()
            restored.load(path)

        self.assertEqual(restored.messages, original.messages)
        bot = chat_bot.SupportBot(
            lambda request, timeout: self.fail(
                "Project recall should use restored conversation history"
            )
        )
        bot.history = restored
        reply = bot.ask("What project am I currently developing?")
        self.assertEqual(
            reply["answer"],
            "You are developing a customer-support chatbot that you want "
            "to integrate with an ERP system.",
        )

    def test_name_and_purchase_are_recalled_from_history(self):
        history = chat_bot.ConversationHistory()
        history.add_user("My name is Tijo. I recently purchased a laptop.")
        history.add_assistant('{"answer":"Thanks, Tijo."}')
        bot = chat_bot.SupportBot(
            lambda request, timeout: self.fail(
                "Known facts should be answered from conversation history"
            )
        )
        bot.history = history

        self.assertEqual(bot.ask("What is my name?")["answer"], "Your name is Tijo.")
        self.assertEqual(
            bot.ask("What product did I purchase?")["answer"],
            "You purchased a laptop.",
        )

    def test_purchase_management_answer_does_not_invent_store_policy(self):
        bot = chat_bot.SupportBot(
            lambda request, timeout: self.fail(
                "General purchase-management guidance is deterministic"
            ),
            enforce_scope=True,
        )

        reply = bot.ask("Can you explain purchase management?")

        self.assertIn("Exact steps depend on the organization's policies", reply["answer"])
        self.assertNotIn("ShopEasy uses", reply["answer"])

    def test_off_topic_request_is_declined_without_ollama_call(self):
        def client(request, timeout):
            self.fail("Off-topic input should not be sent to Ollama")

        with patch.object(chat_bot, "is_in_scope", wraps=self.real_is_in_scope):
            reply = chat_bot.SupportBot(
                client, enforce_scope=True
            ).ask("Tell me a joke.")

        self.assertEqual(
            reply["answer"],
            "I'm designed to assist with customer support and ERP workflows. "
            "Please let me know if you need help with an order, product, "
            "service, or business process.",
        )

    def test_history_survives_network_failure_and_later_recovers(self):
        calls = []

        def client(request, timeout):
            calls.append(request)
            if len(calls) <= chat_bot.MAX_RETRIES:
                raise urllib.error.URLError("internet unavailable")
            return ollama_response({
                "answer": "I can help with that.",
                "category": "general",
                "confidence": "high",
                "next_steps": [],
                "needs_human": False,
            })

        bot = chat_bot.SupportBot(client)
        failed = bot.ask("First request while offline")
        recovered = bot.ask("Second request after service recovery")

        self.assertEqual(failed["answer"], chat_bot.FALLBACK["answer"])
        self.assertEqual(recovered["answer"], "I can help with that.")
        self.assertEqual(len(calls), chat_bot.MAX_RETRIES + 1)

    def test_invalid_non_object_json_raises_invalid_reply(self):
        with self.assertRaises(chat_bot.InvalidReply):
            chat_bot.parse_reply("[]")

    def test_non_boolean_needs_human_is_rejected(self):
        with self.assertRaises(chat_bot.InvalidReply):
            chat_bot.parse_reply(json.dumps({
                "answer": "Reply",
                "category": "general",
                "confidence": "high",
                "next_steps": [],
                "needs_human": "false",
            }))


if __name__ == "__main__":
    unittest.main()
